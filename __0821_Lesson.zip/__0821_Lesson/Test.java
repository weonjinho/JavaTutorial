package __0821_Lesson;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="1234";
		char b = '0';
		for(int i=0;i<a.length();i++) {
			b = a.charAt(i);
			System.out.println(b);
		}
	}

}
