package __0821_Lesson;

import java.util.Scanner;

public class File_01 {

	public static void main(String[] args) {
//		Scanner in = new Scanner(System.in);
//		// aaa + spacebar + bbb + enter를 입력.
//		String a = in.next();
//		b = in.next();
//		c = in.nextLine();
	}

}
