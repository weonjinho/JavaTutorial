package JavaProject_FlowerStore;

public class MainMenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FlowerMge a = new FlowerMge();
	}

}
